CheckMate for Maya 0.8.1

* SYSTEM REQUIREMENTS

Requires Maya 2011 or higher.

* INSTALLATION

To install, extract the "CheckMate-0.8" folder and open The "install.ma" file
in Maya. The scripts will be installed to your user directory. After install,
the CheckMate shelf button will be added to the Custom shelf.

* UNINSTALLATION

To remove CheckMate, select the "Uninstall CheckMate" option from the Options
menu (see below).

* FUNCTIONALITY 

Pressing the CheckMate shelf button opens the CheckMate window.

* TESTS MENU

This menu enables you to run each of the CheckMate tests individually. The
results of these tests can be viewed either on the output line at the bottom
right of the Maya main window, or in the Script Editor. Unless otherwise
specified. NOTE: A result of "False" denotes a PASS. A result of "True"
signifies a fail.

Construction History:
    Checks if any objects have construction history.
    
Zero Area Faces:
    Checks if any faces exist with a surface area of zero.
    
N-sided Faces:
    Checks if there are any N-gons in the scene.
    
Centered at Origin:
    Checks if objects at the top of the hierarchy are centered at the origin.
    
Non-Zero Transforms:
    Checks if any objects have any transforms that are not zero.
    
Polygon and Vertex Count:
    Prompts for a polygon and vertex count, then compares them to the number of
    polygons and vertices in the scene. 
    
Scene Bounding Box:
    Measures the scene in centimeters.
    
Flipped Normals:
    Checks if any normals are flipped incorrectly.
    
Isolated Vertices:
    Checks if any vertices exist that are not connected to any lines or
    polygons.
    
Overlapping Vertices:
    Checks if any vertices occupy the same space.
    
Overlapping (Lamina) Faces:
    Checks if any faces occupy the same space.
    
Default Names:
    Checks if any objects have default names.
    
No Hierarchy:
    Checks if there is more than one top-level transform.
    
No Hidden Objects:
    Finds and unhide all hidden objects. 
    
No Missing Files:
    Checks if any files are referenced improperly.
    
No Missing Materials:
    Checks if any materials are referenced improperly.
    
Missing UVs:
    Checks if any faces are missing UV mappings.
    
Overlapping UVs:
    Checks if any UV faces are overlapping each other.
    
UV Bounding Box:
    Checks if all UVs are within the 0:1 bounding box.

For more information on these tests, see the descriptions on the HTML output
from a full CheckMate report.

* REPORTS MENU

- Save HTML report on current scene

This option outputs to an HTML file in a new directory with the same name as
your scene file and in the same location, along with some test wireframes. The
results of the test will be opened automatically in your web browser once the
test is complete. NOTE: On large scenes, running a full test can take a very
long time and cause Maya to become unresponsive. 

- Open scene and save HTML report

Allows you to choose a scene file and  then automatically runs a full test and
saves a report on it. WARNING: This will close the current scene without
saving. Save your work before using this feature!

- Open folder and save HTML reports

Allows you to choose a folder and automatically runs a full test on each Maya
scene file  within that folder. This option is affected by the "Include
Subdirectories" option (see below). WARNING: This will close the current scene
without saving. Save your work before using this feature!

- Include Subdirectories

When using the "Open folder and save HTML reports" feature, this option
controls whether or not the folder search is done recursively. If enabled, the
script will run tests on all Maya scene files in the folder and also with all
sub-folders.

* OPTIONS MENU

- Verbose

Enables some additional debugging output. This information  can be viewed on
the Script Editor within Maya while the test is running. NOTE: This can create
additional overhead during the test and cause it to take significantly longer.

- Uninstall CheckMate

Removes TurboSquid CheckMate for Maya from your Maya installation. NOTE: The
shelf button will have to be removed manually.

* ADVANCED USAGE

TurboSquid CheckMate for Maya can also be operated from the command line in
batch mode.  This command can be accessed by running the Maya Python
interpreter on the module cm.batch, like so:

$ mayapy -m cm.batch <scene files>

Note that you must either navigate to your maya bin folder or have your PATH
set up to include it in order to invoke maya's python interpreter in this way.
The batch script takes the following options:

    -h/--help           help on using the batch script
    -d/--dir directory  directory to process
    -v/--verbose        enable verbose mode
    -s/--sub            include subdirectories
    -r/--render         enable hardware render
    -q/--quiet          don't show reports
    
    