"""Check-Mate package 

"""

# standard library imports

# related third party imports

# local application/library specific imports


__version__ = '0.7.3'
__author__ = 'Michiel Duvekot'
__copyright__ = "Copyright 2011, Turbosquid"
__credits__ = ["Mark Gerhard", "Ali Volkmar", "Tam Cao"]
__maintainer__ = "Michiel Duvekot"
__email__ = "michiel@thnkr.com"
__status__ = "Production"


